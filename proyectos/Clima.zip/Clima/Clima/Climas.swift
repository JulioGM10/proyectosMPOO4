//
//  Climas.swift
//  Clima
//
//  Created by Macbook on 4/5/19.
//  Copyright © 2019 Sauzun. All rights reserved.
//

import Foundation

struct Results: Codable {
    var data: [Data]
}

struct ClimaData: Codable{
    var city_name: String
    var temp: Double
    var timezone: String
    var datetime: String

    var weather: weatherData

}
struct weatherData: Codable {
    var icon: String
    var description: String
}

