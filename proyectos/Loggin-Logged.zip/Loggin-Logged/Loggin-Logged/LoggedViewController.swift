//
//  LoggedViewController.swift
//  Loggin-Logged
//
//  Created by Macbook on 5/29/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class LoggedViewController: UIViewController {

    @IBOutlet weak var usuario: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        let logged = UserDefaults.standard.bool(forKey: "logged");
        if(!logged)
        {
            self.performSegue(withIdentifier: "loginview", sender: self)
            
        
    }
    }
    
    
    
    @IBAction func logout(_ sender: Any) {
//        do{
//            dismiss(animated: true, completion: nil)
//        }catch let error{
//            print(error.localizedDescription)
//        }
        UserDefaults.standard.set(false, forKey: "logged")
        UserDefaults.standard.synchronize()
        self.performSegue(withIdentifier: "loginview", sender: self)
    }
    

    }
    

