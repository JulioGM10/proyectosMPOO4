//
//  ViewController.swift
//  Loggin-Logged
//
//  Created by Macbook on 5/29/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var correo: UITextField!
    
    @IBOutlet weak var contraseña: UITextField!
    
    @IBOutlet weak var etiqueta: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func crearUsuario(_ sender: UIButton) {
//        guard let userEmail = correo.text,userEmail != "", let userPass = contraseña.text, userPass != "" else {
//            return
        let usus = correo.text;
        let passw = contraseña.text;
        
        if((usus?.isEmpty)! || (passw?.isEmpty)!)
        {
            etiqueta.text = "Debes rellenar los datos"
            return;
     
        }
        UserDefaults.standard.set(usus, forKey: "usus")
        UserDefaults.standard.set(passw, forKey: "passw")
        UserDefaults.standard.synchronize()
   
        self.dismiss(animated: true, completion: nil)
}

}
