//
//  LoginViewController.swift
//  Loggin-Logged
//
//  Created by Macbook on 5/29/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var correo: UITextField!
    
    @IBOutlet weak var contraseña: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    

    @IBAction func login(_ sender: UIButton) {
        
        let  usus = correo.text;
        
        let pass = contraseña.text;
        
        let usuaruioG = UserDefaults.standard.string(forKey: "usus")
        let paaG = UserDefaults.standard.string(forKey: "pass")
        if (usuaruioG == usus)
        {
            if( paaG == pass)
            {
                UserDefaults.standard.set(true, forKey: "login")
                UserDefaults.standard.synchronize()
                self.dismiss(animated: true, completion: nil)
            }
        
      //  guard let userEmail = correo.text,userEmail != "", let userPass = contraseña.text, userPass != "" else {
        //    return
    }
        
    }
    
}
