//
//  TableViewCell.swift
//  ProyectoRopa
//
//  Created by Laboratorio UNAM-Apple 16 on 28/5/19.
//  Copyright © 2019 Agustin. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    
    }

}
