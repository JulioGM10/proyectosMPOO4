//
//  Compras.swift
//  ProyectoRopa
//
//  Created by Laboratorio UNAM-Apple 16 on 28/5/19.
//  Copyright © 2019 Agustin. All rights reserved.
//
import Foundation
import UIKit

struct ProductoC{
    var nombres: String
    var precioT: Double
    var cantidad: Int
}
var cuentaT: Double = 0.00
var listaProducto: [ProductoC] = []

