//
//  TableVCell.swift
//  ProyectoRopa
//
//  Created by Laboratorio UNAM-Apple 16 on 28/5/19.
//  Copyright © 2019 Agustin. All rights reserved.
//

import UIKit

class TableVCell: UITableViewCell {

    @IBOutlet weak var Cant: UILabel!
    
    @IBOutlet weak var Pre: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
